
name = "analitico"

from .dataset import Dataset


from .mixin import AttributesMixin
