from .analiticomodel import AnaliticoModel

from .tabularmodel import TabularModel
from .tabularregressormodel import TabularRegressorModel
from .tabularclassifiermodel import TabularClassifierModel
