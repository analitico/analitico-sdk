This library contains plugins and classes used to access analitico.ai
