
## Analitico SDK

This package contains plugins and classes used to access analitico.ai cloud services and machine learning models. The package can be installed in Jupyter notebooks, Colaboratory notebooks or other Python environments. To access assets stored in Analitico you will need an API token.

## Installation

To install in Python:  
`pip install analitico`

To install on Jupyter, Colaboratory, etc:  
`!pip install analitico`

## Usage

```python
import analitico
import pandas as pd

# Authorize API calls with developer token
api = analitico.authorize("tok_xxx")

# Download a dataset from analitico
dataset = api.get_dataset("ds_xxx")

# Convert dataset to a typed pandas dataframe
df = dataset.get_dataframe()
```
